# My First Project > 2025-05-19 5:54pm
https://universe.roboflow.com/rookiesworkspace/my-first-project-m4dbk

Provided by a Roboflow user
License: CC BY 4.0

